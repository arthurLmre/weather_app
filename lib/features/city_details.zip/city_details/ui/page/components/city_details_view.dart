import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:weather_app/features/city_details/ui/cubit/city_details_cubit.dart';
import 'package:weather_app/features/city_search/data/entities/city.dart';

class CityDetailsView extends StatelessWidget {
  const CityDetailsView({required this.city, super.key});

  final City city;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(city.name)),
      body: BlocBuilder<CityDetailsCubit, CityDetailsState>(
        builder: (context, state) {
          if (state is CityDetailsLoading || state is CityDetailsInitial) {
            return const Center(child: CircularProgressIndicator());
          }

          if (state is CityDetailsSuccess) {
            final forecast = state.forecast;

            return ListView.builder(
              itemCount: forecast.days.length,
              itemBuilder: (context, index) {
                final day = forecast.days[index];

                return ListTile(
                  title: Text(day.date.toString()),
                  subtitle: Text(
                    '${day.minTemperature} °C / '
                    '${day.maxTemperature} °C',
                  ),
                );
              },
            );
          }

          if (state is CityDetailsFailure) {
            return Center(child: Text(state.message));
          }

          return const SizedBox.shrink();
        },
      ),
    );
  }
}
